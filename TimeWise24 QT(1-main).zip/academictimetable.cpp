#include "academictimetable.h"
#include "ui_academictimetable.h"

academictimetable::academictimetable(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::academictimetable)
{
    ui->setupUi(this);
    ptrBus=new bus();
}

academictimetable::~academictimetable()
{
    delete ui;
}

void academictimetable::on_pushButton_Bus_clicked()
{

    ptrBus->show();

}


void academictimetable::on_pushButton_Bus_2_clicked()
{

}

