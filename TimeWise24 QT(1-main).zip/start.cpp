#include "start.h"
#include "ui_start.h"
#include<QPixmap>

start::start(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::start)
{
    ui->setupUi(this);
   // QPixmap pix2(":/image/image/stat2 image.webp");
    //int w = ui->label_pic->width();
    //int h = ui->label_pic->height();
    //ui->label_startpic->setPixmap(pix2.scaled(100,100,Qt::KeepAspectRatio));
    ptrStudent = new Student();
}

start::~start()
{
    delete ui;
}
void start::on_pushButton_student_clicked()
{
    ptrStudent->show();

}


void start::on_pushButton_job_clicked()
{

}


void start::on_pushButton_business_clicked()
{

}


void start::on_pushButton_athlet_clicked()
{

}


void start::on_pushButton_retire_clicked()
{

}


void start::on_pushButton_home_clicked()
{

}


void start::on_pushButton_other_clicked()
{

}


void start::on_pushButton_exit_clicked()
{

}

