#ifndef ACADEMICTIMETABLE_H
#define ACADEMICTIMETABLE_H

#include <QDialog>
#include<bus.h>


namespace Ui {
class academictimetable;
}


class academictimetable : public QDialog
{
    Q_OBJECT

public:
    explicit academictimetable(QWidget *parent = nullptr);
    ~academictimetable();

private slots:
    void on_pushButton_Bus_clicked();

    void on_pushButton_Bus_2_clicked();

private:
    Ui::academictimetable *ui;
    bus *ptrBus;
};

#endif // ACADEMICTIMETABLE_H
