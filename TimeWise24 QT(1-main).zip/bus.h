#ifndef BUS_H
#define BUS_H

#include <QDialog>

namespace Ui {
class bus;
}

class bus : public QDialog
{
    Q_OBJECT

public:
    explicit bus(QWidget *parent = nullptr);
    ~bus();

private:
    Ui::bus *ui;
};

#endif // BUS_H
