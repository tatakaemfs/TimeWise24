#include "student.h"
#include "ui_student.h"

Student::Student(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Student)
{
    ui->setupUi(this);
    ptrAcademic = new academictimetable();
}

Student::~Student()
{
    delete ui;
}

void Student::on_pushButton_act_clicked()
{
    ptrAcademic->show();
}

