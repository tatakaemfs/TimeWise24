#ifndef START_H
#define START_H

#include <QDialog>
#include"student.h"
namespace Ui {
class start;
}

class start : public QDialog
{
    Q_OBJECT

public:
    explicit start(QWidget *parent = nullptr);
    ~start();

private slots:
    void on_pushButton_student_clicked();

    void on_pushButton_job_clicked();

    void on_pushButton_business_clicked();

    void on_pushButton_athlet_clicked();

    void on_pushButton_retire_clicked();

    void on_pushButton_home_clicked();

    void on_pushButton_other_clicked();

    void on_pushButton_exit_clicked();

private:
    Ui::start *ui;
    Student *ptrStudent;
};

#endif // START_H
