#include "login.h"
#include "ui_login.h"
#include<QPixmap>

login::login(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::login)
{
    ui->setupUi(this);
     ptrstart=new start();
    QPixmap pix1(":/image/image/login image.jpg");
    //int w = ui->label_pic->width();
    //int h = ui->label_pic->height();
    ui->label_pic2->setPixmap(pix1.scaled(800,600,Qt::KeepAspectRatio));
    //ptrstart=new start();
}
login::~login()
{
    delete ptrstart;
    delete ui;
}

void login::on_pushButton_login_clicked()
{
    QString Username = ui->lineEdit_username->text();
    QString Password = ui->lineEdit_password->text();
    if(Username=="timewise24"&& Password=="123456")
        ptrstart->show();

}


void login::on_pushButton_cancel_clicked()
{
    QApplication::quit();
}
