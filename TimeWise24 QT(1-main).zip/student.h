#ifndef STUDENT_H
#define STUDENT_H

#include <QDialog>
#include"academictimetable.h"

namespace Ui {
class Student;
}

class Student : public QDialog
{
    Q_OBJECT

public:
    explicit Student(QWidget *parent = nullptr);
    ~Student();

private slots:
    void on_pushButton_act_clicked();

private:
    Ui::Student *ui;
    academictimetable *ptrAcademic;
};

#endif // STUDENT_H
