#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QDateTime>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , darkModeEnabled(false)
{
    ui->setupUi(this);
    ui->stackedWidget->setCurrentIndex(0); // Show login page initially
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_loginButton_clicked()
{
    QString username = ui->usernameLineEdit->text();
    QString password = ui->passwordLineEdit->text();

    if (username == "tanisha" && password == "123") {
        ui->stackedWidget->setCurrentIndex(2); // Go to task page after successful login
    } else {
        QMessageBox::warning(this, "Login Failed", "Invalid username or password.");
    }
}

void MainWindow::on_addTaskButton_clicked()
{
    QString task = ui->taskLineEdit->text();
    QString priority = ui->priorityComboBox->currentText();
    QString category = ui->categoryComboBox->currentText();
    QDateTime dueDate = ui->dueDateEdit->dateTime();
    QString notes = ui->notesTextEdit->toPlainText();

    if (!task.isEmpty()) {
        QString taskItem = task + " [" + priority + "] [" + category + "] (Due: " + dueDate.toString() + ")";
        ui->taskListWidget->addItem(taskItem);
        ui->taskLineEdit->clear();
        ui->notesTextEdit->clear();
    } else {
        QMessageBox::warning(this, "Add Task", "Please enter a task description.");
    }
}

void MainWindow::on_deleteTaskButton_clicked()
{
    QListWidgetItem *item = ui->taskListWidget->currentItem();
    if (item) {
        delete item;
    } else {
        QMessageBox::warning(this, "Delete Task", "Please select a task to delete.");
    }
}

void MainWindow::on_remindTaskButton_clicked()
{
    QMessageBox::information(this, "Remind Task", "Reminder set for the selected task.");
}

void MainWindow::toggleDarkMode()
{
    if (darkModeEnabled) {
        qApp->setStyleSheet("");
    } else {
        qApp->setStyleSheet("QWidget { background-color: #2E2E2E; color: #FFFFFF; }"
                            "QPushButton { background-color: #4E4E4E; color: #FFFFFF; }"
                            "QLineEdit, QTextEdit, QComboBox, QSpinBox { background-color: #3E3E3E; color: #FFFFFF; }");
    }
    darkModeEnabled = !darkModeEnabled;
}

void MainWindow::on_toggleDarkModeButton_clicked()
{
    toggleDarkMode();
}
void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}
/*void MainWindow::on_logHealthDataButton_clicked()
{
    int steps = ui->stepsSpinBox->value();
    int calories = ui->caloriesSpinBox->value();
    int water = ui->waterSpinBox->value();

    QMessageBox::information(this, "Health Data Logged", "Steps: " + QString::number(steps) +
                             "\nCalories: " + QString::number(calories) +
                             "\nWater (cups): " + QString::number(water));
}

void MainWindow::on_calculateSavingsButton_clicked()
{
    int retirementAge = ui->retirementAgeSpinBox->value();
    int savingsGoal = ui->savingsSpinBox->value();

    QMessageBox::information(this, "Retirement Savings", "Retirement Age: " + QString::number(retirementAge) +
                             "\nSavings Goal: $" + QString::number(savingsGoal));
}

void MainWindow::on_joinEventButton_clicked()
{
    QMessageBox::information(this, "Join Event", "Event joined successfully.");
}

void MainWindow::on_createEventButton_clicked()
{
    QMessageBox::information(this, "Create Event
*/

void MainWindow::on_pushButton_2_clicked()
{
     ui->stackedWidget->setCurrentIndex(3);
}

