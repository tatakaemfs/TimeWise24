#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_loginButton_clicked();
    void on_addTaskButton_clicked();
    void on_deleteTaskButton_clicked();
    void on_remindTaskButton_clicked();
    void on_toggleDarkModeButton_clicked();
   // void on_logHealthDataButton_clicked();
   // void on_calculateSavingsButton_clicked();
   // void on_joinEventButton_clicked();
   // void on_createEventButton_clicked();
  //  void on_saveSettingsButton_clicked();
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::MainWindow *ui;
    bool darkModeEnabled;
    void toggleDarkMode();
};

#endif // MAINWINDOW_H
